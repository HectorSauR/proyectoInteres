﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InteresSimple
{
    public partial class FResultado : Form
    {
        public FResultado()
        {
            InitializeComponent();
        }

        private void lbl_ganada_Click(object sender, EventArgs e)
        {

        }

        private void lbl_periodoFinal_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        
    }
}
